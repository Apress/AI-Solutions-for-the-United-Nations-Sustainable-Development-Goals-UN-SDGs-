// Declare the global variables to be used across the script.
var csvData; // Declare a variable for storing the CSV data.
var updatedCSV; // Declare a variable for storing the updated CSV data.
var dynamicTitle; // Declare a variable for storing the chart's title every time it changes.

// Create a method to update the selected year when the slider is adjusted and released.
function updateYear() {
    // Get the range input element.
    const yearRange = document.getElementById("yearRange");
    // Get the selected year element.
    const selectedYear = document.getElementById("selectedYear");
    // Update the selected year text content on the UI.
    selectedYear.textContent = yearRange.value;
    // Set the year filter to the selected year value.
    yearFilter = yearRange.value;
    // Process the updated CSV data.
    processData(updatedCSV);
}

// Create a method to update the selected year when the slider is adjusted without being released.
function dynamicYear() {
    // Get the range input element.
    const yearRange = document.getElementById("yearRange");
    // Get the selected year element.
    const selectedYear = document.getElementById("selectedYear");
    // Update the selected year text content on the UI.
    selectedYear.textContent = yearRange.value;
}

// Create a method to handle file upload event.
function handleFileUpload(event) {
    // Get the uploaded file.
    const file = event.target.files[0];
    // Create a new FileReader object.
    const reader = new FileReader();
    // Create an event listener for when file reading is complete.
    reader.onload = function (e) {
        // Store the CSV data from the file.
        csvData = e.target.result;
        // Process the CSV data.
        processData(csvData);
    };
    // Read the uploaded file as text.
    reader.readAsText(file);
}

// Create a method to process the data, generate the clusters, and plot the results onto a world map.
function generateClusters() {
    // Get the file upload input element.
    const fileUpload = document.getElementById("fileUpload");
    // Get the uploaded file.
    const file = fileUpload.files[0];

    // Check if file is selected.
    if (file) {
        // Use PapaParse to read the file.
        Papa.parse(file, {
            header: true,
            complete: function (results) {
                // Extract the relevant features by specifying the header name of the required columns.
                const data = results.data
                    .map((row) => [parseFloat(row["Cellular Subscription"]), parseFloat(row["Internet Users(%)"]), parseFloat(row["No. of Internet Users"]), parseFloat(row["Broadband Subscription"])])
                    .filter((row) => !row.some(isNaN));
                // Log the extracted original data into console.
                console.log("Original Data:", data);

                // Compute the minimum and maximum values for normalization.
                const minVals = data[0].slice(); // Initialize the minimum value with first row.
                const maxVals = data[0].slice(); // Initialize the maximum value with first row.
                // Iterate through the extracted original data and find the minimum and maximum values.
                data.forEach((row) => {
                    // Iterate through each row of data.
                    row.forEach((val, idx) => {
                        // Update minVals and maxVals for each column.
                        minVals[idx] = Math.min(minVals[idx], val);
                        maxVals[idx] = Math.max(maxVals[idx], val);
                    });
                });

                // Obtain the normalized data from the original data.
                const normalizedData = data.map((row) => row.map((val, idx) => (val - minVals[idx]) / (maxVals[idx] - minVals[idx])));
                // Log the normalized data into console.
                console.log("Normalized Data:", normalizedData);

                // Initialise a variable with the number of clusters required.
                const numClusters = 5;
                
                // Create a variable to perform K-means clustering by passing the normalized data, and the number of clusters.
                // This is performed using the KMeans() method available through the ml.js library.
                const ans = ML.KMeans(normalizedData, numClusters);

                // Log the clustering result and clustering information into the console.
                console.log("Clustering Result:", ans);
                console.log("Cluster Information:", ans.computeInformation(normalizedData));

                // Compute the average of each centroid's values.
                const averagedCentroids = ans.centroids.map((centroid) => ({
                    // Compute the average of the centroid's values and store the size.
                    // The size represents the number of values in a particular cluster.
                    centroid: centroid.centroid.reduce((acc, val) => acc + val, 0) / centroid.centroid.length,
                    size: centroid.size,
                }));

                // Sort the centroids by the averaged values in ascending order.
                const sortedCentroids = averagedCentroids.sort((a, b) => a.centroid - b.centroid);

                // Log the sorted centroids into console.
                console.log("Sorted Centroids:", sortedCentroids);

                // Process to compare the clusters since the labels 0 to 4 are assigned randomly.
                // Each label thus has a centroid, and a size of its cluster.

                // Initialise a variable for the original cluster labels.
                const originalClusterLabels = ans.clusters;
                // Initialise a variable for the original centroids.
                const originalClusterCentroids = ans.centroids;
                // Initialise a variable for the sorted centroids.
                const sortedClusterCentroids = sortedCentroids;

                // Log the original cluster labels, the original centroids, and sorted centroids.
                console.log("originalClusterLabels: ", originalClusterLabels);
                console.log("originalClusterCentroids: ", originalClusterCentroids);
                console.log("sortedClusterCentroids: ", sortedClusterCentroids);

                // Initialize an object to hold the original indexes.
                const originalIndexes = {};
                // Iterate over the originalClusterCentroids array.
                originalClusterCentroids.forEach((centroid, index) => {
                    // Extract the size of the centroid.
                    const centroidSize = centroid.size;
                    // Store the index in the originalIndexes object based on the size.
                    originalIndexes[centroidSize] = index;
                });
                // Log the original indexes into console.
                console.log("Original Indexes", originalIndexes);

                // Initialize an object to hold the sorted indexes.
                const sortedIndexes = {};
                // Iterate over the sortedClusterCentroids array.
                sortedClusterCentroids.forEach((centroid, index) => {
                    // Extract the size of the centroid.
                    const centroidSize = centroid.size;
                    // Store the index in the sortedIndexes object based on the size.
                    sortedIndexes[centroidSize] = index;
                });
                // Log the sorted indexes into console.
                console.log("Sorted Indexes", sortedIndexes);

                // Initialize an array to hold the sorted cluster labels.
                var sortedClusterLabels = [];
                // Initialize an array to hold the corresponding category of each row.
                var category = [];

                // Iterate over each element of the original cluster labels.
                for (var i = 0; i <= originalClusterLabels.length - 1; i++) {
                    // Check if the current label matches the first index of originalIndexes.
                    if (originalClusterLabels[i] == Object.values(originalIndexes)[0]) {
                        // Assign the corresponding sorted index to the sorted cluster labels.
                        sortedClusterLabels[i] = Object.values(sortedIndexes)[0];
                    }
                    // Check if the current label matches the second index of originalIndexes.
                    if (originalClusterLabels[i] == Object.values(originalIndexes)[1]) {
                        // Assign the corresponding sorted index to the sorted cluster labels.
                        sortedClusterLabels[i] = Object.values(sortedIndexes)[1];
                    }
                    // Check if the current label matches the third index of originalIndexes.
                    if (originalClusterLabels[i] == Object.values(originalIndexes)[2]) {
                        // Assign the corresponding sorted index to the sorted cluster labels.
                        sortedClusterLabels[i] = Object.values(sortedIndexes)[2];
                    }
                    // Check if the current label matches the fourth index of originalIndexes.
                    if (originalClusterLabels[i] == Object.values(originalIndexes)[3]) {
                        // Assign the corresponding sorted index to the sorted cluster labels.
                        sortedClusterLabels[i] = Object.values(sortedIndexes)[3];
                    }
                    // Check if the current label matches the fifth index of originalIndexes.
                    if (originalClusterLabels[i] == Object.values(originalIndexes)[4]) {
                        // Assign the corresponding sorted index to the sorted cluster labels.
                        sortedClusterLabels[i] = Object.values(sortedIndexes)[4];
                    }
                }

                // Iterate over each element of the sorted cluster labels.
                for (var i = 0; i <= sortedClusterLabels.length - 1; i++) {
                    // Check if the current label matches 0.
                    if (sortedClusterLabels[i] == 0) {
                        // Assign "Underdeveloped" to the corresponding category
                        category[i] = "Underdeveloped";
                    }
                    // Check if the current label matches 1.
                    if (sortedClusterLabels[i] == 1) {
                        // Assign "Emerging" to the corresponding category.
                        category[i] = "Emerging";
                    }
                    // Check if the current label matches 2.
                    if (sortedClusterLabels[i] == 2) {
                        // Assign "Developing" to the corresponding category.
                        category[i] = "Developing";
                    }
                    // Check if the current label matches 3.
                    if (sortedClusterLabels[i] == 3) {
                        // Assign "Developed" to the corresponding category.
                        category[i] = "Developed";
                    }
                    // Check if the current label matches 4.
                    if (sortedClusterLabels[i] == 4) {
                        // Assign "Highly Developed" to the corresponding category.
                        category[i] = "Highly Developed";
                    }
                }
                // Log the sorted cluster labels into console.
                console.log(sortedClusterLabels);

                // Add label to each row in the original data.
                for (let i = 0; i < results.data.length; i++) {
                    results.data[i]["Label"] = sortedClusterLabels[i]; // Add label to the row.
                    results.data[i]["Category"] = category[i]; // Add category to the row.
                }

                // Log the data together with the added labels and categories into console.
                console.log("Data with Labels and Categories:", results.data);

                // Convert the updated data back to CSV format.
                updatedCSV = Papa.unparse(results.data, { header: true });

                // Pass the updated data into the processData() method.
                processData(updatedCSV);

                // Get the checkbox element from the UI.
                var checkbox = document.getElementById("downloadCheckbox");
                // Check if the checkbox is checked and prompt the user to download the updated CSV file.
                if (checkbox.checked) {
                    // Create a Blob object containing the updated CSV data.
                    const blob = new Blob([updatedCSV], { type: "text/csv" });
                    // Create a new anchor element.
                    const link = document.createElement("a");
                    // Set the URL of the anchor element to the object URL of the Blob.
                    link.href = window.URL.createObjectURL(blob);
                    // Set the download attribute of the anchor element to specify the filename for download.
                    link.download = "country-internet-clustered.csv";
                    // Simulate a click event on the anchor element to trigger the download.
                    link.click();
                }
            },
        });
    } else {
        // Log a message into console in case a file has not been selected.
        console.log("Please select a file.");
    }
}

// Create a class as a custom template for creating the world map object.
class CustomWorldMap {
    constructor(containerId) {
        // Set the ID of the container where the map will be plotted.
        this.containerId = containerId;
    }

    plot(data) {
        // Create an object to prepare data for the map.
        const plotData = [
            {
                // Define the type of plot as choropleth.
                type: "choropleth",
                // Extract locations from the data.
                locations: data.map((entry) => entry.code),
                // Extract values from the data.
                z: data.map((entry) => entry.value),
                // Specify the title of the map with custom styling.
                text: data.map((entry) => `<span style="font-family: 'Fira Sans', sans-serif;">${entry.hover}</span>`),
                // Define colorscale for the choropleth map using the same colour palette as the legend.
                colorscale: [
                    [0, "#FF204E"],
                    [0.25, "#FFA3FD"],
                    [0.5, "#00FFD1"],
                    [0.75, "#2CD3E1"],
                    [1, "#7900FF"],
                ],
                // Set the minimum value of the color axis.
                zmin: 0,
                // Set the maximum value of the color axis.
                zmax: 4,
                // Hide the color scale.
                showscale: false,
                // Customize marker properties.
                marker: {
                    line: {
                        // Set color of marker lines.
                        color: "#FFFFFF",
                        // Set width of marker lines.
                        width: 1.2,
                    },
                },
            },
        ];

        // Define layout configuration for the map.
        const layout = {
            // Set the title of the map.
            title: dynamicTitle,
            // Configure font properties.
            font: {
                size: 14,
                color: "White",
                family: "Fira Sans",
            },
            // Configure properties of the geographical plot.
            geo: {
                scope: "world",
                resolution: 50,
                showland: false,
                bgcolor: "#000e20",
                coloraxis_showscale: false,
                framecolor: "#000e20",
                coastlinecolor: "#FFFFFF",
                showcoastlines: true,
                projection: { type: "rect" },
            },
            // Set the background color of the plot area.
            paper_bgcolor: "#000e20",
            // Set margins for the plot.
            margin: {
                l: 60,
                r: 60,
                t: 60,
                b: 20,
            },
        };

        // Plot the map using Plotly.
        Plotly.newPlot(this.containerId, plotData, layout);
    }
}

// Create a method to process the CSV data and plot the map dynamically.
function processData(csvData) {
    // Split CSV data into rows.
    const rows = csvData.split("\n");
    // Initialize an array to store extracted data.
    const data = [];
    // Generate dynamic title based on selected year.
    dynamicTitle = "Worldwide Internet Connectivity Development (" + document.getElementById("yearRange").value + ")";

    // Iterate over each row of the CSV data.
    rows.forEach((row) => {
        // Ignore empty rows.
        if (row.trim() !== "") {
            // Split the row into columns using comma as delimiter.
            const columns = row.split(",");
            // Ensure each row has the expected number of columns.
            if (columns.length === 10) {
                // Extract year from the row.
                const year = columns[3].trim();
                // Retrieve the selected year from the range input.
                var yearFilter = document.getElementById("yearRange").value;
                // Check if the row corresponds to the selected year.
                if (year == yearFilter) {
                    // Extract code, name, value, and category from the row.
                    const code = columns[2].toUpperCase().trim();
                    const name = columns[1].trim();
                    const value = parseFloat(columns[8].trim());
                    const category = columns[9].trim();
                    // Generate hover text for the data point.
                    var hover = name + ": " + category;
                    // Add extracted data to the array.
                    data.push({
                        code: code,
                        name: name,
                        value: value,
                        hover: hover,
                    });
                }
            } else {
                // Log a warning into console for rows with an invalid number of columns.
                console.warn("Invalid row:", row);
            }
        }
    });

    // Plot the map with the processed data using the customWorldMap object.
    customWorldMap.plot(data);
}

// Instantiate a CustomWorldMap object with the specified container ID.
const customWorldMap = new CustomWorldMap("map-container");