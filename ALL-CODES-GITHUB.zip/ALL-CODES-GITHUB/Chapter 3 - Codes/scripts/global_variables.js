// Fields
const nRowsField = document.getElementById('nRowsField');
const ratioNitrogen = document.getElementById('ratioNitrogen');
const ratioPhosphorous = document.getElementById('ratioPhosphorous');
const ratioPotassium = document.getElementById('ratioPotassium');
const tempValue = document.getElementById('tempValue');
const humidityValue = document.getElementById('humidityValue');
const pHValue = document.getElementById('pHValue');
const rainfallValue = document.getElementById('rainfallValue');
const resultField = document.getElementById('resultField');

// Containers
const container4 = document.getElementById('container4');
const container5 = document.getElementById('container5');
const container6 = document.getElementById('container6');

// Button
const kNNBtn = document.getElementById('kNNBtn');
const decisionTreeBtn = document.getElementById('decisionTreeBtn');
const randomForBtn = document.getElementById('randomForBtn');
const mlpBtn = document.getElementById('mlpBtn');
const runBtn = document.getElementById('runBtn');

var dataFromCSV;
var onRead;

// Rice
var n_rice = []; var p_rice = []; var k_rice = []; var temp_rice = []; var humi_rice = [];
var ph_rice = []; var rainfall_rice = [];

// Maize
var n_maize = [];
var p_maize = [];
var k_maize = [];
var temp_maize = [];
var humi_maize = [];
var ph_maize = [];
var rainfall_maize = [];

// Chickpea
var n_chickpea = [];
var p_chickpea = [];
var k_chickpea = [];
var temp_chickpea = [];
var humi_chickpea = [];
var ph_chickpea = [];
var rainfall_chickpea = [];

// Kidneybeans
var n_kidneybeans = [];
var p_kidneybeans = [];
var k_kidneybeans = [];
var temp_kidneybeans = [];
var humi_kidneybeans = [];
var ph_kidneybeans = [];
var rainfall_kidneybeans = [];

// Pigeonpeas
var n_pigeonpeas = [];
var p_pigeonpeas = [];
var k_pigeonpeas = [];
var temp_pigeonpeas = [];
var humi_pigeonpeas = [];
var ph_pigeonpeas = [];
var rainfall_pigeonpeas = [];

// Mothbeans
var n_mothbeans = [];
var p_mothbeans = [];
var k_mothbeans = [];
var temp_mothbeans = [];
var humi_mothbeans = [];
var ph_mothbeans = [];
var rainfall_mothbeans = [];

// Mungbeans
var n_mungbean= [];
var p_mungbean = [];
var k_mungbean = [];
var temp_mungbean = [];
var humi_mungbean = [];
var ph_mungbean = [];
var rainfall_mungbean = [];

// Blackgram
var n_blackgram = [];
var p_blackgram = [];
var k_blackgram = [];
var temp_blackgram = [];
var humi_blackgram = [];
var ph_blackgram = [];
var rainfall_blackgram = [];

//Lentil
var n_lentil= [];
var p_lentil = [];
var k_lentil = [];
var temp_lentil = [];
var humi_lentil = [];
var ph_lentil = [];
var rainfall_lentil = [];

// Pomegranate
var n_pomegranate = [];
var p_pomegranate = [];
var k_pomegranate = [];
var temp_pomegranate = [];
var humi_pomegranate = [];
var ph_pomegranate = [];
var rainfall_pomegranate = [];

// Banana
var n_banana= [];
var p_banana = [];
var k_banana = [];
var temp_banana = [];
var humi_banana = [];
var ph_banana = [];
var rainfall_banana = [];

// Mango
var n_mango= [];
var p_mango = [];
var k_mango = [];
var temp_mango = [];
var humi_mango = [];
var ph_mango = [];
var rainfall_mango = [];

// Grapes
var n_grapes= [];
var p_grapes = [];
var k_grapes = [];
var temp_grapes = [];
var humi_grapes = [];
var ph_grapes = [];
var rainfall_grapes = [];

// Watermelon
var n_watermelon= [];
var p_watermelon = [];
var k_watermelon = [];
var temp_watermelon = [];
var humi_watermelon = [];
var ph_watermelon = [];
var rainfall_watermelon = [];

// Muskmelon
var n_muskmelon= [];
var p_muskmelon = [];
var k_muskmelon = [];
var temp_muskmelon = [];
var humi_muskmelon = [];
var ph_muskmelon = [];
var rainfall_muskmelon = [];

// Apple
var n_apple= [];
var p_apple = [];
var k_apple = [];
var temp_apple = [];
var humi_apple = [];
var ph_apple = [];
var rainfall_apple = [];

// Orange
var n_orange = [];
var p_orange = [];
var k_orange = [];
var temp_orange = [];
var humi_orange = [];
var ph_orange = [];
var rainfall_orange = [];

// Papaya
var n_papaya = [];
var p_papaya = []; var k_papaya = []; var temp_papaya = [];
var humi_papaya = []; var ph_papaya = []; var rainfall_papaya = [];

// Coconut
var n_coconut= [];
var p_coconut = []; var k_coconut = []; var temp_coconut = [];
var humi_coconut = []; var ph_coconut = []; var rainfall_coconut = [];

// Cotton
var n_cotton = [];
var p_cotton = []; var k_cotton = []; var temp_cotton = [];
var humi_cotton = []; var ph_cotton = []; var rainfall_cotton = [];

// Jute
var n_jute = [];
var p_jute = []; var k_jute = []; var temp_jute = [];
var humi_jute = []; var ph_jute = []; var rainfall_jute = [];

// Coffee
var n_coffee = [];
var p_coffee = []; var k_coffee = []; var temp_coffee = [];
var humi_coffee = []; var ph_coffee = []; var rainfall_coffee = [];


// Variable to hold all features of the values from the datase
var dataset = [];

// Variable to hold the value of all the flower types
var prediction = []; 

// define the array variables for holding the data
var n = [];
var p = [];
var k = [];
var temp = [];
var humidity =[];
var ph = [];
var rainfall = [];
var label =[];
var encodedLabel =[];
var predictedLabel = [];

// label_class
var classes = [
    'rice', 'maize', 'chickpea', 'kidneybeans', 
    'mothbeans', 'mungbean', 'blackgram', 'lentil', 'pomegranate',
     'banana', 'mango', 'grapes', 'watermelon', 'muskmelon',
     'apple', 'orange', 'papaya', 'coconut', 'cotton',
     'jute', 'coffee'];

var classes_num = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21];