function MLP() {
  console.log("MLP");
  // Set conditions for reading of CSV files
  var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.csv|.txt)$/;
  var fileUpload = document.getElementById("fileUpload");
  if (regex.test(fileUpload.value.toLowerCase())) {
    if (typeof FileReader != "undefined") {
      // Read CSV file
      var reader = new FileReader();
      reader.readAsText(fileUpload.files[0]);

      // Load all the data from the file
      reader.onload = function (e) {
        var csvData = e.target.result;
        var data = Papa.parse(csvData, {
          header: true,
          dynamicTyping: true,
        });

        // Get number of rows
        var numberofrows = data.data.length;
        var nrows = parseInt(document.getElementById("nRowsField").value);
        var table = document.createElement("table");
        var rows = e.target.result.split("\n");

        // Display data in a table
        for (var i = 0; i <= nrows; i++) {
          var cells = rows[i].split(",");
          if (cells.length > 1) {
            var row = table.insertRow(-1);
            for (var j = 0; j < cells.length; j++) {
              var cell = row.insertCell(-1);
              cell.innerHTML = cells[j];
            }
          }
        }

        // Show table on the DOM
        container5.appendChild(table);

        // Read the data and save in arrays
        for (var i = 0; i < numberofrows - 1; i++) {
          n[i] = data.data[i].N;
          p[i] = data.data[i].P;
          k[i] = data.data[i].K;
          temp[i] = data.data[i].temperature;
          humidity[i] = data.data[i].humidity;
          ph[i] = data.data[i].ph;
          rainfall[i] = data.data[i].rainfall;
          label[i] = data.data[i].label;
          encodedLabel[i] = data.data[i].encodedlabel;
        }

        // Performing MLP classification
        classify(n, p, k, temp, humidity, ph, rainfall, label, encodedLabel);
      };
    }
  }
}

function classify(n, p, k, temp, humidity, ph, rainfall, label, encodedLabel) {
  var userN = parseFloat(ratioNitrogen.value);
  var userP = parseFloat(ratioPhosphorous.value);
  var userK = parseFloat(ratioPotassium.value);
  var userTemp = parseFloat(tempValue.value);
  var userHumi = parseFloat(humidityValue.value);
  var userPh = parseFloat(pHValue.value);
  var userRain = parseFloat(rainfallValue.value);

  const network = new brain.NeuralNetwork({
    // Create a new NeuralNetwork for the classification task using Brain JS
    hiddenLayers: [44], // Specify the number of neurons in the hidden layer(s)
    learningRate: 0.01, // Specify the learning rate
    errorThresh: 0.005, // Specify the error threshold for training
    inputSize: 7, // Specify the input size (number of input features)
  });

  var inputs = [];
  var outputs = [];
  // Initialising the variable that will hold the training dataset
  var trainingData = [];

  // Iterating throughout the dataset
  for (var i = 0; i <= label.length - 1; i++) {
    inputs[0] = n[i];
    inputs[1] = p[i];
    inputs[2] = k[i];
    inputs[3] = temp[i];
    inputs[4] = humidity[i];
    inputs[5] = ph[i];
    inputs[6] = rainfall[i];

    if (label[i] == "rice") {
      outputs[0] = 1;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "maize") {
      outputs[0] = 0;
      outputs[1] = 1;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "chickpea") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 1;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "kidneybeans") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 1;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "pigeonpeas") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 1;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "mothbeans") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 1;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "mungbean") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 1;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "blackgram") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 1;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "lentil") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 1;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "pomegranate") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 1;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "banana") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 1;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "mango") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 1;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "grapes") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 1;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "watermelon") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 1;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "muskmelon") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 1;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "apple") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 1;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "orange") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 1;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "papaya") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 1;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "coconut") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 1;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "cotton") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 1;
      outputs[20] = 0;
      outputs[21] = 0;
    }

    if (label[i] == "jute") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 0;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 1;
      outputs[21] = 0;
    }

    if (label[i] == "coffee") {
      outputs[0] = 0;
      outputs[1] = 0;
      outputs[2] = 1;
      outputs[3] = 0;
      outputs[4] = 0;
      outputs[5] = 0;
      outputs[6] = 0;
      outputs[7] = 0;
      outputs[8] = 0;
      outputs[9] = 0;
      outputs[10] = 0;
      outputs[11] = 0;
      outputs[12] = 0;
      outputs[13] = 0;
      outputs[14] = 0;
      outputs[15] = 0;
      outputs[16] = 0;
      outputs[17] = 0;
      outputs[18] = 0;
      outputs[19] = 0;
      outputs[20] = 0;
      outputs[21] = 1;
    }
    // Filling the training dataset
    trainingData.push({ input: [...inputs], output: [...outputs] });
  }

  // Train the neural network
  const trainingStats = network.train(trainingData, {
    iterations: 200000, // Specify the number of training iterations
    errorThresh: 0.005, // Specify the error threshold for training
    log: false, // Log training progress to the console
  });

  console.log("Training statistics:", trainingStats);

  // Testing the neural network through prediction percentage accuracy evaluation
  var rows = [];

  for (var i = 0; i <= label.length - 1; i++) {
    // Filling the values for every row
    var row = [n[i], p[i], k[i], temp[i], humidity[i], ph[i], rainfall[i]];
    rows[i] = row;
  }

  console.log("Rows: ");
  console.log(rows);

  // Performing classification for each row in the dataset
  var predictedValues = [];

  rows.forEach((data) => {
    const output = network.run(data);
    const predictedClass = output.indexOf(Math.max(...output)); // Obtaining the predicted class
    console.log("Input:", data, "Predicted Class:", predictedClass);
    predictedValues.push(predictedClass); // Store the predicted values into an array for comparison
  });

  // Initialise a counter which will increment upon each correct classification
  var count = 0;
  // Increment the counter by iterating throughout the dataset
  for (var i = 0; i <= label.length - 1; i++) {
    if (predictedValues[i] == encodedLabel[i]) {
      count = count + 1;
    }
  }

  // Calculate the percentage accuracy by counting how many correct classifications were made
  var percentageAccuracy = (count / label.length) * 100;
  console.log("Percentage Accuracy: " + percentageAccuracy);

  // Round the accuracy to 2 d.p
  percentageAccuracy =
    Math.round((percentageAccuracy + Number.EPSILON) * 100) / 100;

  var userN = parseFloat(ratioNitrogen.value);
  var userP = parseFloat(ratioPhosphorous.value);
  var userK = parseFloat(ratioPotassium.value);
  var userTemp = parseFloat(tempValue.value);
  var userHumi = parseFloat(humidityValue.value);
  var userPh = parseFloat(pHValue.value);
  var userRain = parseFloat(rainfallValue.value);

  // Classification for user-requested values on web-page using the run() method
  const userOutput = network.run([
    userN,
    userP,
    userK,
    userTemp,
    userHumi,
    userPh,
    userRain,
  ]);
  var userPredictedClass = userOutput.indexOf(Math.max(...userOutput));
  console.log(
    "User Input:",
    userN,
    userP,
    userK,
    userTemp,
    userHumi,
    userPh,
    userRain,
    "User Predicted Class:",
    userPredictedClass
  );

  var predicted;
  if (userPredictedClass == 0) {
    predicted = "rice";
  } else if (userPredictedClass == 1) {
    predicted = "maize";
  } else if (userPredictedClass == 2) {
    predicted = "chickpea";
  } else if (userPredictedClass == 3) {
    predicted = "kidneybeans";
  } else if (userPredictedClass == 4) {
    predicted = "pigeonpeas";
  } else if (userPredictedClass == 5) {
    predicted = "mothbeans";
  } else if (userPredictedClass == 6) {
    predicted = "mungbean";
  } else if (userPredictedClass == 7) {
    predicted = "blackgram";
  } else if (userPredictedClass == 8) {
    predicted = "lentil";
  } else if (userPredictedClass == 9) {
    predicted = "pomegranate";
  } else if (userPredictedClass == 10) {
    predicted = "banana";
  } else if (userPredictedClass == 11) {
    predicted = "mango";
  } else if (userPredictedClass == 12) {
    predicted = "grapes";
  } else if (userPredictedClass == 13) {
    predicted = "watermelon";
  } else if (userPredictedClass == 14) {
    predicted = "muskmelon";
  } else if (userPredictedClass == 15) {
    predicted = "apple";
  } else if (userPredictedClass == 16) {
    predicted = "orange";
  } else if (userPredictedClass == 17) {
    predicted = "papaya";
  } else if (userPredictedClass == 18) {
    predicted = "coconut";
  } else if (userPredictedClass == 19) {
    predicted = "cotton";
  } else if (userPredictedClass == 20) {
    predicted = "jute";
  } else if (userPredictedClass == 21) {
    predicted = "coffee";
  }

  resultField.value = "" + predicted;
  console.log(`Percentage Accuracy: ${percentageAccuracy} %`);
}
