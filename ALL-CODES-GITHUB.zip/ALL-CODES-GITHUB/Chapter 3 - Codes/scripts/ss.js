 if (label[i] == "rice") {
    outputs[0] = 1; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "maize") {
    outputs[0] = 0; outputs[1] = 1; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "chickpea") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 1; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "kidneybeans") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 1;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "pigeonpeas") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 1; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "mothbeans") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 1; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "mungbean") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 1; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "blackgram") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 1;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "lentil") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 1; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "pomegranate") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 1; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "banana") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 1; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "mango") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 1;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "grapes") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 1; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "watermelon") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 1; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "muskmelon") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 1; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "apple") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 1;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "orange") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 1; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "papaya") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 1; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "coconut") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 1; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "cotton") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 1;
    outputs[20] = 0; outputs[21] = 0;
}

if (label[i] == "jute") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 0; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 1; outputs[21] = 0;
}

if (label[i] == "coffee") {
    outputs[0] = 0; outputs[1] = 0; outputs[2] = 1; outputs[3] = 0;
    outputs[4] = 0; outputs[5] = 0; outputs[6] = 0; outputs[7] = 0;
    outputs[8] = 0; outputs[9] = 0; outputs[10] = 0; outputs[11] = 0;
    outputs[12] = 0; outputs[13] = 0; outputs[14] = 0; outputs[15] = 0;
    outputs[16] = 0; outputs[17] = 0; outputs[18] = 0; outputs[19] = 0;
    outputs[20] = 0; outputs[21] = 1;
}