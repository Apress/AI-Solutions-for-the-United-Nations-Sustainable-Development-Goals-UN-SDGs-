function randomForestPred() {
    console.log("Random Forest Classifier");
    var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.csv|.txt)$/;
    var fileUpload = document.getElementById("fileUpload");
    if (regex.test(fileUpload.value.toLowerCase())) {
        if (typeof (FileReader) != "undefined") {

            var reader = new FileReader();
            reader.readAsText(fileUpload.files[0]);

            reader.onload = function (e) {
                var csvData = e.target.result; 
                var data = Papa.parse(csvData, {
                    header: true,
                    dynamicTyping: true,
                });

                var numberofrows = data.data.length;
                var nrows =parseInt(document.getElementById("nRowsField").value);
                var table = document.createElement("table");
                var rows = e.target.result.split("\n");

                for (var i = 0; i <= nrows; i++) { 
                    var cells = rows[i].split(",");
                    if (cells.length > 1) { 
                        var row = table.insertRow(-1); 
                        for (var j = 0; j < cells.length; j++) { 
                            var cell = row.insertCell(-1);
                            cell.innerHTML = cells[j]; 
                        }
                    }
                }

                container5.appendChild(table);
                
                for(var i = 0; i < numberofrows-1 ; i++){

                    n[i] = data.data[i].N;
                    p[i] = data.data[i].P;
                    k[i] = data.data[i].K;
                    temp[i] = data.data[i].temperature;
                    humidity[i] =data.data[i].humidity;
                    ph[i] = data.data[i].ph;
                    rainfall[i] = data.data[i].rainfall;
                    label[i] =data.data[i].encodedlabel;
                    
                    // Push all the values collected to the dataset array
                    dataset.push([n[i], p[i], k[i], temp[i], humidity[i], ph[i], rainfall[i]]);
                    
                    // Push the values of the Species column to the prediction array.
                    prediction.push(label[i]);
                }

                var input = [
                    [parseFloat(ratioNitrogen.value),
                    parseFloat(ratioPhosphorous.value),
                    parseFloat(ratioPotassium.value),
                    parseFloat(tempValue.value),
                    parseFloat(humidityValue.value),
                    parseFloat(pHValue.value),
                    parseFloat(rainfallValue.value)]
                ];

                var options = {
                    seed: 3,
                    maxFeatures: 0.8,
                    replacement: true,
                    nEstimators: 25
                };

                var random_forest = new ML.RandomForestClassifier(options);
                random_forest.train(dataset, prediction);
                var ans = random_forest.predict(input);// predict
                console.log(ans);    
                var predicted;

                if (ans[0] === 0) {predicted = 'rice'}
                else if (ans[0] === 1) {predicted = 'maize'}
                else if (ans[0] === 2) {predicted = 'chickpea'}
                else if (ans[0] === 3) {predicted = 'kidneybeans'}
                else if (ans[0] === 4) {predicted = 'pigeonpeas'}
                else if (ans[0] === 5) {predicted = 'mothbeans'}
                else if (ans[0] === 6) {predicted = 'mungbean'}
                else if (ans[0] === 7) {predicted = 'blackgram'}
                else if (ans[0] === 8) {predicted = 'lentil'}
                else if (ans[0] === 9) {predicted = 'pomegranate'}
                else if (ans[0] === 10) {predicted = 'banana'}
                else if (ans[0] === 11) {predicted = 'mango'}
                else if (ans[0] === 12) {predicted = 'grapes'}
                else if (ans[0] === 13) {predicted = 'watermelon'}
                else if (ans[0] === 14) {predicted = 'muskmelon'}
                else if (ans[0] === 15) {predicted = 'apple'}
                else if (ans[0] === 16) {predicted = 'orange'}
                else if (ans[0] === 17) {predicted = 'papaya'}
                else if (ans[0] === 18) {predicted = 'coconut'}
                else if (ans[0] === 19) {predicted = 'cotton'}
                else if (ans[0] === 20) {predicted = 'jute'}
                else if (ans[0] === 21) {predicted = 'coffee'};

                resultField.value = "" + predicted;
                
                for(var i = 0; i < numberofrows-1 ; i++){

                    const n = data.data[i].N;
                    const p= data.data[i].P;
                    const k = data.data[i].K;
                    const temp = data.data[i].temperature;
                    const humidity =data.data[i].humidity;
                    const ph = data.data[i].ph;
                    const rainfall = data.data[i].rainfall;
                    
                    const newInput = [[n , p , k , temp , humidity, ph, rainfall]];
                    const newAns = random_forest.predict(newInput);
                    predictedLabel.push(newAns[0]);
                }
                
                // The order of the arguments are important !!!
                const CM2 = ML.ConfusionMatrix.fromLabels(label, predictedLabel);
                console.log(CM2.getAccuracy()); //100%
                Matrix({
                    container : container6,
                    data      : CM2.matrix,
                    labels    : classes
                });
            }
        }
    }
}