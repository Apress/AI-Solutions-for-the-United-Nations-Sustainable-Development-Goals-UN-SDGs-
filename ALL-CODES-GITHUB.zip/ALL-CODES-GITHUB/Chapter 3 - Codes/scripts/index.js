// Dataset : https://www.kaggle.com/datasets/atharvaingle/crop-recommendation-dataset

nRowsField.value = 10;
ratioNitrogen.value = 100;
ratioPhosphorous.value = 53;
ratioPotassium.value = 41;
tempValue.value = 24.52;
humidityValue.value = 80.94;
pHValue.value = 6.35;
rainfallValue.value = 200.1;

runBtn.onclick = () => {
  var dataset = [];
  var prediction = [];
  var n = [];
  var p = [];
  var k = [];
  var temp = [];
  var humidity = [];
  var ph = [];
  var rainfall = [];
  var label = [];
  var encodedLabel = [];
  var predictedLabel = [];

  if (kNNBtn.checked) {
    knnPred();
  } else if (decisionTreeBtn.checked) {
    decisionTreePred();
  } else if (randomForBtn.checked) {
    randomForestPred();
  } else if (mlpBtn.checked) {
    MLP();
  }
};
