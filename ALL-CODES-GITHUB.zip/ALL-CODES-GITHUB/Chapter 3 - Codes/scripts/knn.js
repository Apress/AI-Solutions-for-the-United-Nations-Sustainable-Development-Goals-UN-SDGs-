function knnPred() {
  console.log("K-NN");
  // Conditions to read CSV files
  var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.csv|.txt)$/;
  var fileUpload = document.getElementById("fileUpload");
  if (regex.test(fileUpload.value.toLowerCase())) {
    if (typeof FileReader != "undefined") {
      // FileReader to read CSV file
      var reader = new FileReader();
      reader.readAsText(fileUpload.files[0]);

      // Load Data from CSV
      reader.onload = function (e) {
        var csvData = e.target.result;
        // Parse Data from Spreadsheet
        var data = Papa.parse(csvData, {
          header: true,
          dynamicTyping: true,
        });

        // Get number of rows in table
        var numberofrows = data.data.length;
        var nrows = parseInt(document.getElementById("nRowsField").value);
        var table = document.createElement("table");
        var rows = e.target.result.split("\n");

        // Create a table to display the data
        for (var i = 0; i <= nrows; i++) {
          var cells = rows[i].split(",");
          if (cells.length > 1) {
            var row = table.insertRow(-1);
            for (var j = 0; j < cells.length; j++) {
              var cell = row.insertCell(-1);
              cell.innerHTML = cells[j];
            }
          }
        }

        // Add the table to DOM
        container5.appendChild(table);

        // Read full contents and save in arrays
        for (var i = 0; i < numberofrows - 1; i++) {
          n[i] = data.data[i].N;
          p[i] = data.data[i].P;
          k[i] = data.data[i].K;
          temp[i] = data.data[i].temperature;
          humidity[i] = data.data[i].humidity;
          ph[i] = data.data[i].ph;
          rainfall[i] = data.data[i].rainfall;
          label[i] = data.data[i].label;

          // Push all the values collected to the dataset array
          dataset.push([
            n[i],
            p[i],
            k[i],
            temp[i],
            humidity[i],
            ph[i],
            rainfall[i],
          ]);

          // Push the values of the Species column to the prediction array.
          prediction.push(label[i]);
        }

        console.log(dataset);
        console.log(prediction);

        // Create Model input
        var input = [
          parseFloat(ratioNitrogen.value),
          parseFloat(ratioPhosphorous.value),
          parseFloat(ratioPotassium.value),
          parseFloat(tempValue.value),
          parseFloat(humidityValue.value),
          parseFloat(pHValue.value),
          parseFloat(rainfallValue.value),
        ];

        // Create ML Model
        var knn = new ML.KNN(dataset, prediction, { k: 4 });
        // Find prediction
        var classify = knn.predict(input);
        resultField.value = "" + classify;

        // Use for Loop to pass all initial data into the Model
        for (var i = 0; i < numberofrows - 1; i++) {
          const n = data.data[i].N;
          const p = data.data[i].P;
          const k = data.data[i].K;
          const temp = data.data[i].temperature;
          const humidity = data.data[i].humidity;
          const ph = data.data[i].ph;
          const rainfall = data.data[i].rainfall;

          const newInput = [n, p, k, temp, humidity, ph, rainfall];
          predictedLabel.push(knn.predict(newInput));
        }

        console.log(predictedLabel);
        // The order of the arguments are important !!!
        const CM2 = ML.ConfusionMatrix.fromLabels(label, predictedLabel);
        console.log(CM2.getAccuracy()); //98.272 %
        // Plot Matrix Confusion for KNN
        Matrix({
          container: container6,
          data: CM2.matrix,
          labels: classes,
        });
      };
    }
  }
}
