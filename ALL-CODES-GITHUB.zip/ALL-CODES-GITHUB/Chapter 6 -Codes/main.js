// Arrays to store air pollutants data
var o3 = [];
var co = [];
var pm10 = [];
var pm25 = [];
var time = [];

// Linear regression predictions
var predictedO3Linear;
var predictedCoLinear;
var predictedPm10Linear;
var predictedPm25Linear;

// Polynomial regression predictions
var predictedO3Poly;
var predictedCoPoly;
var predictedPm10Poly;
var predictedPm25Poly;

// MLP (Multi-Layer Perceptron) predictions
var predictedO3MLP;
var predictedCoMLP;
var predictedPm10MLP;
var predictedPm25MLP;

// LSTM (Long Short-Term Memory) predictions
var predictedO3LSTM;
var predictedCoLSTM;
var predictedPm10LSTM;
var predictedPm25LSTM;

// Arrays to store all predictions for each model
var predictedO3LinearAll = [];
var predictedCoLinearAll = [];
var predictedPm10LinearAll = [];
var predictedPm25LinearAll = [];

var predictedO3PolyAll = [];
var predictedCoPolyAll = [];
var predictedPm10PolyAll = [];
var predictedPm25PolyAll = [];

var predictedO3MLPAll = [];
var predictedCoMLPAll = [];
var predictedPm10MLPAll = [];
var predictedPm25MLPAll = [];

var predictedO3LSTMAll = [];
var predictedCoLSTMAll = [];
var predictedPm10LSTMAll = [];
var predictedPm25LSTMAll = [];

// Mean Absolute Percentage Error (MAPE) arrays
var mapeO3 = [];
var mapeCo = [];
var mapePm10 = [];
var mapePm25 = [];

// Variable to store the predicted day
var predDay;

// Function to handle users input, start data fetching, perform regression and calculate mape
function enter() {
    // Get the values of input fields
    var fromDate = document.getElementById("fromDate").value;
    var toDate = document.getElementById("toDate").value;
    predDay = parseFloat(document.getElementById("day").value);

    // Get selected city and algorithm from dropdown menus
    var selectElement = document.getElementById("city");
    var selectedOption = selectElement.options[selectElement.selectedIndex];
    var city = selectedOption.text;

    var selectElement2 = document.getElementById("algorithm");
    var selectedOption2 = selectElement2.options[selectElement2.selectedIndex];
    var algorithm = selectedOption2.text;

    // Construct API URL for fetching historical air quality data
    const url = 'https://api.weatherbit.io/v2.0/history/airquality?&city=' + city + '&country=MU&start_date=' + fromDate +
        '&end_date=' + toDate + '&tz=local&key=014690483c1f480da471c53ee686d196';

    // Set options for the fetch request
    const options = {
        method: 'GET',
    };

    // Fetch data from the API
    fetch(url, options)
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then((data) => {
            console.log(data);
            // Extract data fields from the API response
            var dataset = data.data;
            getFields(dataset);

            // Calculate the predicted time based on the selected day
            var lastDate = time[0];
            var predTime = lastDate + (predDay * 60 * 60 * 24);

            // Perform predictions based on the selected algorithm
            switch (algorithm) {
                case "Linear":
                    // Single value linear regression
                    predictedO3Linear = predLin(time, o3, predTime);
                    predictedCoLinear = predLin(time, co, predTime);
                    predictedPm10Linear = predLin(time, pm10, predTime);
                    predictedPm25Linear = predLin(time, pm25, predTime);

                    // Linear regression for all data
                    predictedO3LinearAll = predLinAll(time, o3);
                    predictedCoLinearAll = predLinAll(time, co);
                    predictedPm10LinearAll = predLinAll(time, pm10);
                    predictedPm25LinearAll = predLinAll(time, pm25);
                    break;
                case "Polynomial":
                    // Single value Polynomial regression
                    predictedO3Poly = predPoly(time, o3, predTime);
                    predictedCoPoly = predPoly(time, co, predTime);
                    predictedPm10Poly = predPoly(time, pm10, predTime);
                    predictedPm25Poly = predPoly(time, pm25, predTime);

                    // Polynomial regression for all data
                    predictedO3PolyAll = predPolyAll(time, o3);
                    predictedCoPolyAll = predPolyAll(time, co);
                    predictedPm10PolyAll = predPolyAll(time, pm10);
                    predictedPm25PolyAll = predPolyAll(time, pm25);
                    break;
                case "MLP":
                    // Single value MLP regression
                    predictedO3MLP = predMLP(predDay, o3);
                    predictedCoMLP = predMLP(predDay, co);
                    predictedPm10MLP = predMLP(predDay, pm10);
                    predictedPm25MLP = predMLP(predDay, pm25);

                    // MLP regression for all data
                    predictedO3MLPAll = predMLPAll(predDay, o3);
                    predictedCoMLPAll = predMLPAll(predDay, co);
                    predictedPm10MLPAll = predMLPAll(predDay, pm10);
                    predictedPm25MLPAll = predMLPAll(predDay, pm25);
                    break;
                case "LSTM":
                    // Single value LSTM regression
                    predictedO3LSTM = predLSTM(predDay, o3);
                    predictedCoLSTM = predLSTM(predDay, co);
                    predictedPm10LSTM = predLSTM(predDay, pm10);
                    predictedPm25LSTM = predLSTM(predDay, pm25);

                    // LSTM regression for all data
                    predictedO3LSTMAll = predLSTMAll(predDay, o3);
                    predictedCoLSTMAll = predLSTMAll(predDay, co);
                    predictedPm10LSTMAll = predLSTMAll(predDay, pm10);
                    predictedPm25LSTMAll = predLSTMAll(predDay, pm25);
                    break;
                default:
            }
            // Calculate MAPE (Mean Absolute Percentage Error) for O3 pollutant based on different algorithms
            mapeO3[0] = MAPE(o3, predictedO3LinearAll);
            mapeO3[1] = MAPE(o3, predictedO3PolyAll);
            mapeO3[2] = MAPE(o3, predictedO3MLPAll);
            mapeO3[3] = MAPE(o3, predictedO3LSTMAll);
            console.log("Mape of o3: " + mapeO3);

            // Calculate MAPE for CO pollutant based on different algorithms
            mapeCo[0] = MAPE(co, predictedCoLinearAll);
            mapeCo[1] = MAPE(co, predictedCoPolyAll);
            mapeCo[2] = MAPE(co, predictedCoMLPAll);
            mapeCo[3] = MAPE(co, predictedCoLSTMAll);
            console.log("Mape of co: " + mapeCo);

            // Calculate MAPE for PM10 pollutant based on different algorithms
            mapePm10[0] = MAPE(pm10, predictedPm10LinearAll);
            mapePm10[1] = MAPE(pm10, predictedPm10PolyAll);
            mapePm10[2] = MAPE(pm10, predictedPm10MLPAll);
            mapePm10[3] = MAPE(pm10, predictedPm10LSTMAll);
            console.log("Mape of pm10: " + mapePm10);

            // Calculate MAPE for PM25 pollutant based on different algorithms
            mapePm25[0] = MAPE(pm25, predictedPm25LinearAll);
            mapePm25[1] = MAPE(pm25, predictedPm25PolyAll);
            mapePm25[2] = MAPE(pm25, predictedPm25MLPAll);
            mapePm25[3] = MAPE(pm25, predictedPm25LSTMAll);
            console.log("Mape of pm25: " + mapePm25);

            // Display predictions based on the selected algorithm
            dispPreds(algorithm);

            // Variables to store the final predicted values
            var predictedO3;
            var predictedCo;
            var predictedPm10;
            var predictedPm25;

            // Select the predicted values based on the chosen algorithm
            switch (algorithm) {
                case "Linear":
                    predictedO3 = predictedO3Linear;
                    predictedCo = predictedCoLinear;
                    predictedPm10 = predictedPm10Linear;
                    predictedPm25 = predictedPm25Linear;
                    break;
                case "Polynomial":
                    predictedO3 = predictedO3Poly;
                    predictedCo = predictedCoPoly;
                    predictedPm10 = predictedPm10Poly;
                    predictedPm25 = predictedPm25Poly;
                    break;
                case "MLP":
                    predictedO3 = predictedO3MLP;
                    predictedCo = predictedCoMLP;
                    predictedPm10 = predictedPm10MLP;
                    predictedPm25 = predictedPm25MLP;
                    break;
                case "LSTM":
                    predictedO3 = predictedO3LSTM;
                    predictedCo = predictedCoLSTM;
                    predictedPm10 = predictedPm10LSTM;
                    predictedPm25 = predictedPm25LSTM;
                    break;
                default:
                // Default case if the algorithm is not recognized
            }

            // Plotting values for each pollutant
            console.log("chek");
            console.log(predictedPm25MLPAll);
            plot(o3, predictedO3LinearAll, predictedO3PolyAll, predictedO3MLPAll, predictedO3LSTMAll, predictedO3, "o3 µg/m³", "Concentration of o3", "myPlot1", algorithm);
            plot(co, predictedCoLinearAll, predictedCoPolyAll, predictedCoMLPAll, predictedCoLSTMAll, predictedCo, "co µg/m³", "Concentration of co", "myPlot2", algorithm);
            plot(pm10, predictedPm10LinearAll, predictedPm10PolyAll, predictedPm10MLPAll, predictedPm10LSTMAll, predictedPm10, "pm10 µg/m³", "Concentration pm10", "myPlot3", algorithm);
            plot(pm25, predictedPm25LinearAll, predictedPm25PolyAll, predictedPm25MLPAll, predictedPm25LSTMAll, predictedPm25, "pm25 µg/m³", "Concentration of pm25", "myPlot4", algorithm);
        })
        .catch((error) => {
            console.error('Fetch error:', error);
        });
}

// Function to extract fields (o3, co, pm10, pm25, time) from the dataset
function getFields(dataset) {
    for (var i = 0; i < dataset.length; i++) {
        var data = dataset[i];
        o3.push(data.o3);
        co.push(data.co);
        pm10.push(data.pm10);
        pm25.push(data.pm25);
        time.push(data.ts);
    }
}

// Function for single value linear regression prediction
function predLin(x, y, xtarget) {
    // Create a Simple Linear Regression model using ML library
    var regression = new ML.SimpleLinearRegression(x, y);
    // Predict the value at xtarget using the trained model
    var prediction = regression.predict(xtarget);
    return prediction;
}

// Function for linear regression predictions for all data points
function predLinAll(x, y) {
    // Create a Simple Linear Regression model using ML library
    var regression = new ML.SimpleLinearRegression(x, y);
    // Predict values for all data points using the trained model
    var predictions = [];
    for (var i = 0; i < x.length; i++) {
        var prediction = regression.predict(x[i]);
        predictions.push(prediction);
    }
    return predictions;
}

// Function for single value polynomial regression prediction
function predPoly(x, y, xtarget) {
    // Create a Polynomial Regression model using ML library
    var regression = new ML.PolynomialRegression(x, y, 5); // 5 is the degree of the polynomial
    // Predict the value at xtarget using the trained polynomial model
    var prediction = regression.predict(xtarget);
    return prediction;
}

// Function for polynomial regression predictions for all data points
function predPolyAll(x, y) {
    // Create a Polynomial Regression model using ML library
    var regression = new ML.PolynomialRegression(x, y, 5); // 5 is the degree of the polynomial
    // Predict values for all data points using the trained polynomial model
    var predictions = [];
    for (var i = 0; i < x.length; i++) {
        var prediction = regression.predict(x[i]);
        predictions.push(prediction);
    }
    return predictions;
}

// Function to predict a single value using MLP (Multi-Layer Perceptron) regression
function predMLP(x, y) {
    // Set the size of the sliding window for prediction
    var windowSize = x * 24;

    // Create a Perceptron (MLP) with input size, hidden layer size, and output size
    var regression = new neataptic.architect.Perceptron(windowSize, windowSize, 1);

    // Normalize the target values (y) to be in the range of 0 to 1
    var min = Math.min.apply(Math, y);
    var max = Math.max.apply(Math, y);

    var inputs = [];
    var outputs = [];
    var inputValue, outputValue;
    var pValue = 0;

    var counter = windowSize + pValue - 1;
    var index = 0;
    var valueFill = 0;

    // Initialize the training dataset
    var trainingSet = [];

    // Create a sliding window for window-sized-steps prediction
    for (let a = 0; a < (y.length - (windowSize + pValue - 1)); a++) {
        // Fill the "inputs" array with a window number of elements
        for (let j = valueFill; j < (valueFill + windowSize); j++) {
            // Normalize each input to be in the range of 0 to 1
            inputValue = (y[j] - min) / (max - min);
            inputs[index] = inputValue;
            index = index + 1;
        }

        index = 0;
        valueFill = valueFill + 1;

        // Normalize each output variable to be in the range of 0 to 1
        outputValue = (y[counter] - min) / (max - min);
        outputs[0] = outputValue;

        // Add input-output pairs to the training set
        trainingSet.push({ input: [...inputs], output: [...outputs] });
        counter = counter + 1;
    }

    // Train the MLP regression model with hyperparameters
    regression.train(trainingSet, {
        error: 0.0001,
        iterations: 500,
        rate: 0.001,
        momentum: 0.9
    });

    // Make a prediction using the last input in the training set
    var predicted = regression.activate(trainingSet[trainingSet.length - 1].input);

    // Denormalize the prediction to the original range
    predicted = predicted * (max - min) + min;

    return predicted;
}

// Function to predict values for all data points using MLP regression
function predMLPAll(x, y) {
    // Set the size of the sliding window for prediction
    var windowSize = x * 24;
    // Create a Perceptron (MLP) with input size, hidden layer size, and output size
    var regression = new neataptic.architect.Perceptron(windowSize, windowSize, 1);
    // Normalize the target values (y) to be in the range of 0 to 1
    var min = Math.min.apply(Math, y);
    var max = Math.max.apply(Math, y);
    var inputs = [];
    var outputs = [];
    var inputValue, outputValue;
    var pValue = 0;
    var counter = windowSize + pValue - 1;
    var index = 0;
    var valueFill = 0;
    // Initialize the training dataset
    var trainingSet = [];
    // Create a sliding window for window-sized-steps prediction
    for (let a = 0; a < (y.length - (windowSize + pValue - 1)); a++) {
        // Fill the "inputs" array with a window number of elements
        for (let j = valueFill; j < (valueFill + windowSize); j++) {
            // Normalize each input to be in the range of 0 to 1
            inputValue = (y[j] - min) / (max - min);
            inputs[index] = inputValue;
            index = index + 1;
        }
        index = 0;
        valueFill = valueFill + 1;
        // Normalize each output variable to be in the range of 0 to 1
        outputValue = (y[counter] - min) / (max - min);
        outputs[0] = outputValue;
        // Add input-output pairs to the training set
        trainingSet.push({ input: [...inputs], output: [...outputs] });
        counter = counter + 1;
    }
    // Train the MLP regression model with hyperparameters
    regression.train(trainingSet, {
        error: 0.0001,
        iterations: 500,
        rate: 0.001,
        momentum: 0.9
    });
    // Initialize an array to store predictions
    var predictions = [];
    for (var i = 1; i < windowSize; i++) {
        predictions.push(0);
    }
    // Make predictions for each input in the training set
    for (var i = 0; i < trainingSet.length; i++) {
        var predicted = regression.activate(trainingSet[i].input);
        // Denormalize each prediction to the original range
        predicted = predicted * (max - min) + min;
        predictions.push(predicted);
    }
    return predictions;
}
// Function to predict a single value using LSTM (Long Short-Term Memory) regression
function predLSTM(x, y) {
    // Set the size of the sliding window for prediction
    var windowSize = x * 24;

    // Create an LSTM with input size, hidden layer size, and output size
    var regression = new neataptic.architect.LSTM(windowSize, windowSize, 1);

    // Normalize the target values (y) to be in the range of 0 to 1
    var min = Math.min.apply(Math, y);
    var max = Math.max.apply(Math, y);

    var inputs = [];
    var outputs = [];
    var inputValue, outputValue;
    var pValue = 0;

    var counter = windowSize + pValue - 1;
    var index = 0;
    var valueFill = 0;

    // Initialize the training dataset
    var trainingSet = [];

    // Create a sliding window for window-sized-steps prediction
    for (let a = 0; a < (y.length - (windowSize + pValue - 1)); a++) {
        // Fill the "inputs" array with a window number of elements
        for (let j = valueFill; j < (valueFill + windowSize); j++) {
            // Normalize each input to be in the range of 0 to 1
            inputValue = (y[j] - min) / (max - min);
            inputs[index] = inputValue;
            index = index + 1;
        }

        index = 0;
        valueFill = valueFill + 1;

        // Normalize each output variable to be in the range of 0 to 1
        outputValue = (y[counter] - min) / (max - min);
        outputs[0] = outputValue;

        // Add input-output pairs to the training set
        trainingSet.push({ input: [...inputs], output: [...outputs] });
        counter = counter + 1;
    }

    // Train the LSTM regression model with hyperparameters
    regression.train(trainingSet, {
        error: 0.0001,
        iterations: 500,
        rate: 0.001,
        momentum: 0.9
    });

    // Make a prediction using the last input in the training set
    var predicted = regression.activate(trainingSet[trainingSet.length - 1].input);

    // Denormalize the prediction to the original range
    predicted = predicted * (max - min) + min;

    return predicted;
}

// Function to predict values for all data points using LSTM regression
function predLSTMAll(x, y) {
    // Set the size of the sliding window for prediction
    var windowSize = x * 24;
    // Create an LSTM with input size, hidden layer size, and output size
    var regression = new neataptic.architect.LSTM(windowSize, windowSize, 1);
    // Normalize the target values (y) to be in the range of 0 to 1
    var min = Math.min.apply(Math, y);
    var max = Math.max.apply(Math, y);
    var inputs = [];
    var outputs = [];
    var inputValue, outputValue;
    var pValue = 0;
    var counter = windowSize + pValue - 1;
    var index = 0;
    var valueFill = 0;
    // Initialize the training dataset
    var trainingSet = [];
    // Create a sliding window for window-sized-steps prediction
    for (let a = 0; a < (y.length - (windowSize + pValue - 1)); a++) {
        // Fill the "inputs" array with a window number of elements
        for (let j = valueFill; j < (valueFill + windowSize); j++) {
            // Normalize each input to be in the range of 0 to 1
            inputValue = (y[j] - min) / (max - min);
            inputs[index] = inputValue;
            index = index + 1;
        }
        index = 0;
        valueFill = valueFill + 1;
        // Normalize each output variable to be in the range of 0 to 1
        outputValue = (y[counter] - min) / (max - min);
        outputs[0] = outputValue;
        // Add input-output pairs to the training set
        trainingSet.push({ input: [...inputs], output: [...outputs] });
        counter = counter + 1;
    }
    // Train the LSTM regression model with hyperparameters
    regression.train(trainingSet, {
        error: 0.0001,
        iterations: 500,
        rate: 0.001,
        momentum: 0.9
    });

    // Initialize an array to store predictions
    var predictions = [];
    for (var i = 1; i < windowSize; i++) {
        predictions.push(0);
    }
    // Make predictions for each input in the training set
    for (var i = 0; i < trainingSet.length; i++) {
        var predicted = regression.activate(trainingSet[i].input);
        // Denormalize each prediction to the original range
        predicted = predicted * (max - min) + min;
        predictions.push(predicted);
    }
    return predictions;
}

// Function to plot data and predictions using Plotly
function plot(data, dataLinear, dataPoly, dataMLP, dataLSTM, predicted, unit, title, plotID, algorithm) {
    // Create an array 'x' for time values normalized to days
    var x = [];
    var lastDate = time[time.length - 1];
    for (var i = 0; i < time.length; i++) {
        x.push((time[i] - lastDate) / (60 * 60 * 24));
    }
    // Calculate the predicted time normalized to days
    var predictedTime = time[0] + (predDay * 60 * 60 * 24);
    predictedTime = (predictedTime - lastDate) / (60 * 60 * 24);
    // Create data traces for the main dataset and predicted values
    var data1 = {
        x: x, y: data,
        mode: "markers",
        name: 'Data set',
        line: {
            color: 'blue',
            width: 2
        }
    };
    var data2 = {
        x: [predictedTime], y: [predicted],
        mode: "markers",
        name: 'Predicted',
        line: {
            color: 'black',
            width: 2
        }
    };
    var data3;
    // Create data trace for the selected algorithm (Linear, Polynomial, MLP, LSTM)
    switch (algorithm) {
        case "Linear":
            data3 = {
                x: x, y: dataLinear,
                mode: "line",
                name: 'Linear',
                line: {
                    color: 'red',
                    width: 2
                }
            };
            break;

        case "Polynomial":
            data3 = {
                x: x, y: dataPoly,
                mode: "line",
                name: 'Polynomial',
                line: {
                    color: 'red',
                    width: 2
                }
            };
            break;
        case "MLP":
            data3 = {
                x: x.slice(predDay * 24), y: dataMLP.slice(predDay * 24),
                mode: "line",
                name: 'MLP',
                line: {
                    color: 'red',
                    width: 2
                }
            };
            break;
        case "LSTM":
            data3 = {
                x: x.slice(predDay * 24), y: dataLSTM.slice(predDay * 24),
                mode: "line",
                name: 'LSTM',
                line: {
                    color: 'red',
                    width: 2
                }
            };
            break;
        default:
    }
    // Set layout parameters for the plot
    var layout = {
        xaxis: { title: "time/day" },
        yaxis: { title: unit },
        title: title
    };
    // Create the plot using Plotly
    Plotly.newPlot(plotID, [data1, data2, data3], layout);
}

// Function to merge arrays into a 2D array
function merge(arr) {
    var data = []
    for (var i = 0; i < arr[0].length; i++) {
        var row = [];
        for (var j = 0; j < arr.length; j++) {
            row.push(arr[j][i]);
        }
        data.push(row);
    }
    return data;
}

// Function to calculate Mean Absolute Percentage Error (MAPE) between two arrays
function MAPE(arr1, arr2) {
    var n = arr1.length;
    var sumPercentageErrors = 0;

    // Iterate through each element and calculate the percentage error
    for (let i = 0; i < n; i++) {
        var actual = arr1[i];
        var forecasted = arr2[i];

        // Skip if actual or forecasted value is zero to avoid division by zero
        if (actual === 0 || forecasted === 0) {
            continue;
        }

        // Calculate and accumulate the percentage error
        var percentageError = Math.abs((actual - forecasted) / actual) * 100;
        sumPercentageErrors += percentageError;
    }

    // Calculate the mean percentage error
    var meanPercentageError = sumPercentageErrors / n;
    return meanPercentageError;
}

// Function to display predictions and MAPE values for a selected algorithm
function dispPreds(algorithm) {
    // Get textarea elements by ID
    var textarea1 = document.getElementById("predictions");
    var textarea2 = document.getElementById("mapes");
    var s1, s2;

    // Generate prediction and MAPE strings based on the selected algorithm
    switch (algorithm) {
        case "Linear":
            s1 = algorithm + " \n" +
                "o3: " + predictedO3Linear.toFixed(2) + " µg/m³\n" +
                "co: " + predictedCoLinear.toFixed(2) + " µg/m³\n" +
                "pm10: " + predictedPm10Linear.toFixed(2) + " µg/m³\n" +
                "pm25: " + predictedPm25Linear.toFixed(2) + " µg/m³\n";

            s2 = algorithm + " \n" +
                "o3: " + mapeO3[0].toFixed(2) + " %\n" +
                "co: " + mapeCo[0].toFixed(2) + " %\n" +
                "pm10: " + mapePm10[0].toFixed(2) + " %\n" +
                "pm25: " + mapePm25[0].toFixed(2) + " %\n";
            break;

        case "Polynomial":
            s1 = algorithm + " \n" +
                "o3: " + predictedO3Poly.toFixed(2) + " µg/m³\n" +
                "co: " + predictedCoPoly.toFixed(2) + " µg/m³\n" +
                "pm10: " + predictedPm10Poly.toFixed(2) + " µg/m³\n" +
                "pm25: " + predictedPm25Poly.toFixed(2) + " µg/m³\n";

            s2 = algorithm + " \n" +
                "o3: " + mapeO3[1].toFixed(2) + " %\n" +
                "co: " + mapeCo[1].toFixed(2) + " %\n" +
                "pm10: " + mapePm10[1].toFixed(2) + " %\n" +
                "pm25: " + mapePm25[1].toFixed(2) + " %\n";
            break;

        case "MLP":
            s1 = algorithm + " \n" +
                "o3: " + predictedO3MLP.toFixed(2) + " µg/m³\n" +
                "co: " + predictedCoMLP.toFixed(2) + " µg/m³\n" +
                "pm10: " + predictedPm10MLP.toFixed(2) + " µg/m³\n" +
                "pm25: " + predictedPm25MLP.toFixed(2) + " µg/m³\n";
            l
            s2 = algorithm + " \n" +
                "o3: " + mapeO3[2].toFixed(2) + " %\n" +
                "co: " + mapeCo[2].toFixed(2) + " %\n" +
                "pm10: " + mapePm10[2].toFixed(2) + " %\n" +
                "pm25: " + mapePm25[2].toFixed(2) + " %\n";
            break;

        case "LSTM":
            s1 = algorithm + " \n" +
                "o3: " + predictedO3LSTM.toFixed(2) + " µg/m³\n" +
                "co: " + predictedCoLSTM.toFixed(2) + " µg/m³\n" +
                "pm10: " + predictedPm10LSTM.toFixed(2) + " µg/m³\n" +
                "pm25: " + predictedPm25LSTM.toFixed(2) + " µg/m³\n";

            s2 = algorithm + " \n" +
                "o3: " + mapeO3[3].toFixed(2) + " %\n" +
                "co: " + mapeCo[3].toFixed(2) + " %\n" +
                "pm10: " + mapePm10[3].toFixed(2) + " %\n" +
                "pm25: " + mapePm25[3].toFixed(2) + " %\n";
            break;

        default:
    }

    // Set the values of the textareas
    textarea1.value = s1;
    textarea2.value = s2;
}

var predDay2;
// Function to handle user input, fetch air pollution data, perform classification, and calculate accuracy
function enter2() {
    // Get the values of various input fields
    var fromDate = document.getElementById("fromDate").value;
    var toDate = document.getElementById("toDate").value;
    var predDay2 = parseFloat(document.getElementById("day2").value);
    var selectElement = document.getElementById("city");
    var selectedOption = selectElement.options[selectElement.selectedIndex];
    var city = selectedOption.text;
    var selectElement2 = document.getElementById("algorithm2");
    var selectedOption2 = selectElement2.options[selectElement2.selectedIndex];
    var algorithm = selectedOption2.text;

    // Convert date values to UNIX timestamps
    var start = parseInt((new Date(fromDate).getTime() / 1000).toFixed(0));
    var end = parseInt((new Date(toDate).getTime() / 1000).toFixed(0));

    // Fetch latitude and longitude using OpenWeatherMap API
    const urlLatLon = 'http://api.openweathermap.org/geo/1.0/direct?q=' + city + '&limit=1&appid=76e55f2fcf72476bb3dca3c87a7d19ca';
    fetch(urlLatLon, { method: 'GET' })
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then((results) => {
            // Extract latitude and longitude from API response
            var lat = results[0].lat;
            var lon = results[0].lon;

            // Fetch air pollution history data using latitude, longitude, start, and end parameters
            const urlData = 'http://api.openweathermap.org/data/2.5/air_pollution/history?lat=' + lat + '&lon=' + lon +
                '&start=' + start + '&end=' + end + '&appid=76e55f2fcf72476bb3dca3c87a7d19ca';

            fetch(urlData, { method: 'GET' })
                .then((response) => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then((results) => {
                    // Extract relevant data from the API response
                    var content = results.list;
                    var CO = [];
                    var NO2 = [];
                    var O3 = [];
                    var SO2 = [];
                    var PM10 = [];
                    var PM25 = [];
                    var AQI = [];
                    var TIME = [];
                    var dataset = [];

                    // Process API data and populate arrays
                    for (var i = 0; i < content.length; i++) {
                        var sample = content[i].components;
                        var inp = [sample.co, sample.no2, sample.o3, sample.s02, sample.pm10, sample.pm2_5];
                        dataset.push(inp);
                        CO.push(sample.co);
                        NO2.push(sample.no2);
                        O3.push(sample.o3);
                        SO2.push(sample.so2);
                        PM10.push(sample.pm10);
                        PM25.push(sample.pm2_5);
                        AQI.push(content[i].main.aqi);
                        TIME.push(content.length - i);
                    }

                    // Calculate the last date and the predicted time
                    var lastDate = TIME[0];
                    var predTime = lastDate + (predDay2 * 24);

                    // Get the last values for each pollutant for prediction
                    var predCO = CO[CO.length - 1];
                    var predNO2 = NO2[NO2.length - 1];
                    var predO3 = O3[O3.length - 1];
                    var predSO2 = SO2[SO2.length - 1];
                    var predPM10 = PM10[PM10.length - 1];
                    var predPM25 = PM25[PM25.length - 1];

                    // Input array for classification
                    var input = [predCO, predNO2, predO3, predSO2, predPM10, predPM25];

                    var classification;
                    var classifications;

                    // Perform classification based on the selected algorithm
                    switch (algorithm) {
                        case "KNN":
                            var model = new ML.KNN(dataset, AQI, { k: 4 });
                            classification = model.predict(input);
                            classifications = model.predict(dataset);
                            break;
                        case "Decision Tree":
                            var options = {
                                gainFunction: "gini",
                                maxDepth: 10,
                                minNumSamples: 3
                            };
                            var model = new ML.DecisionTreeClassifier(options);
                            model.train(dataset, AQI);
                            classification = model.predict([input]);
                            classifications = model.predict(dataset);
                            break;
                        case "Random Forest":
                            var options = {
                                gainFunction: "gini",
                                maxDepth: 10,
                                minNumSamples: 3
                            };
                            var model = new ML.RandomForestClassifier(options);
                            model.train(dataset, AQI);
                            classification = model.predict([input]);
                            classifications = model.predict(dataset);
                            break;
                        default:
                    }

                    // Display the classification result and accuracy
                    console.log("classification");
                    console.log(classification);
                    document.getElementById("classification").value = classification;
                    console.log("classifications");
                    console.log(classifications);
                    var accuracy = Accuracy(classifications, AQI);
                    console.log("accuracy");
                    console.log(accuracy);
                    document.getElementById("accuracy").value = accuracy + "%";
                })
                .catch((error) => {
                    console.error('Fetch error:', error);
                });
        })
        .catch((error) => {
            console.error('Fetch error:', error);
        });
}

// Function to calculate accuracy given two arrays
function Accuracy(arr1, arr2) {
    var sum = 0;

    // Count the number of matching elements
    for (var i = 0; i < arr1.length; i++) {
        if (arr1[i] === arr2[i]) {
            sum++;
        }
    }

    // Calculate and return accuracy percentage
    var acc = (sum / arr1.length) * 100;
    return acc;
}