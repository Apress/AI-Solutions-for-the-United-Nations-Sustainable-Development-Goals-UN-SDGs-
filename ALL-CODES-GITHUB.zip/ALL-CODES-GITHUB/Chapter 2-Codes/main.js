var power = [];
var wspeed = [];
var wdirection = [];
var pressure = [];
var temperature = [];
var values = [];

function upload() {
    var fileUpload = document.getElementById("fileUpload");
    var reader = new FileReader();
    reader.readAsText(fileUpload.files[0]); //Read csv file
    reader.onload = function (e) {
        var csvData = e.target.result;
        var rows = csvData.split("\n"); 
        for (var i = 1; i < rows.length; i++) {
            var columns = rows[i].split(",");
            power.push(parseFloat(columns[0]));
            wspeed.push(columns[1]);
            wdirection.push(columns[2]);
            pressure.push(columns[3]);
            temperature.push(columns[4]);
        }

        for (var i = 1; i < rows.length; i++) {
            var columns = rows[i].split(",");
            var row = [];
            for (var j = 1; j < columns.length; j++) {
                row.push(parseFloat(columns[j]));
            }
            values.push(row);
        }
        var k = parseFloat(document.getElementById("k").value);
        var inputs = [];
        inputs.push(parseFloat(document.getElementById("n1").value));
        inputs.push(parseFloat(document.getElementById("n2").value));
        inputs.push(parseFloat(document.getElementById("n3").value));
        inputs.push(parseFloat(document.getElementById("n4").value));
        var prediction = getKnnRegression(values, power, k, inputs);
        document.getElementById("prediction").value = prediction;

        var predictions = [];
        for (var i = 0; i < 8760; i++) {
            var input = values[i];
            var pred = getKnnRegression(values, power, k, input);
            predictions.push(pred);
        }
        var actuals = []
        for (var i = 0; i < 8760; i++) {
            actuals.push(power[i]);
        }
        var mape = MAPE(predictions, actuals);
        document.getElementById("mape").value = mape + "%";
    }
}

function getKnnRegression(x, y, k, inputs) {//x independent, y dependent
    var distances = [];
    // Loop through each existing data point to calculate distances
    for (var i = 0; i < x.length; i++) {
        var distance = 0;

    // Calculate Euclidean distance between the new data point and existing data points
        for (var j = 0; j < inputs.length; j++) {
            distance = distance + (x[i][j] - inputs[j]) ** 2;
        }
        distance = distance ** 0.5;
        distances.push(distance);
    }
    var copy = distances.slice();
    copy.sort((a, b) => a - b);
    var nearestIdx = [];
    for (var i = 0; i < k; i++) {
        var idx = distances.indexOf(copy[i]);
        nearestIdx.push(idx);
        distances[idx] = Infinity; // Mark already selected distances as Infinity to avoid re-selection
    }
    var nearestNeighbours = [];
    for (var i = 0; i < k; i++) {
        nearestNeighbours.push(y[nearestIdx[i]]);
    }
    var regression = mean(nearestNeighbours);
    return regression;
}

function mean(arr) {
    var sum = 0;
    for (var i = 0; i < arr.length; i++) {
        sum = sum + arr[i];
    }
    var mean = sum / arr.length;
    return mean;
}
// calculation of MAPE
function MAPE(arr1, arr2) {
    var n = arr1.length;
    var sumPercentageErrors = 0;
    for (let i = 0; i < n; i++) {
        var actual = arr1[i];
        var forecasted = arr2[i];
        if (actual === 0) {
            continue;
        }
        var percentageError = Math.abs((actual - forecasted) / actual) * 100;
        sumPercentageErrors += percentageError;
    }
    var meanPercentageError = sumPercentageErrors / n;
    return meanPercentageError;
}