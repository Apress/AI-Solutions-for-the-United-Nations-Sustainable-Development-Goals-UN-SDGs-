function Upload() {
  var fileUpload = document.getElementById("fileUpload");
  var reader = new FileReader();
  reader.readAsText(fileUpload.files[0]);
  reader.onload = function (e) {
    var csvData = e.target.result;
    var data = Papa.parse(csvData, {
      header: true,
      dynamicTyping: true,
    });

    var nrows = parseInt(data.data.length);
    
    var xx = [];
    var yy = [];
// Extract data from CSV rows and populate arrays
    for (var i = 0; i < nrows-1; i++) {

      yy.push(parseFloat(data.data[i].SystemPower));
      xx.push(parseFloat(data.data[i].Windspeed));

      var xtgt = parseFloat(document.getElementById("n1").value);
      var degree = parseFloat(document.getElementById("n2").value);
    }
    var vandermondeMatrix = [];
    var powers = [];

    for (var j = 1; j <= degree; j++) {
      powers.push(j);
    }

    var firstRow = [xx.length].concat(
      powers.map((power) => xx.reduce((acc, value) => acc + Math.pow(value, power), 0))
    );

    vandermondeMatrix.push(firstRow);

    for (var i = 2; i <= degree + 1; i++) {
      var previousRow = vandermondeMatrix[i - 2];
      var row = previousRow.slice(-degree); // Last 'degree' elements of the previous row

      var power = i + degree - 1; // Power starts from degree + 1
      var sumPower = xx.reduce((acc, value) => acc + Math.pow(value, power), 0);
      row.push(sumPower);

      vandermondeMatrix.push(row);
    }

    myMatrix = math.matrix(vandermondeMatrix);
    console.log("Matrix X is " + myMatrix);

    var yMatrix = [yy.reduce((acc, value) => acc + value, 0)];
    for (var i = 1; i <= degree; i++) {
      yMatrix.push(xx.reduce((acc, value, index) => acc + Math.pow(value, i) * yy[index], 0));
    }
    console.log("Matrix Y is " + yMatrix);

    var xy = math.lusolve(myMatrix, yMatrix);
    var coefficients = math.squeeze(xy).toArray();
    console.log("The coefficients are " + coefficients);

    var ypred = coefficients.reduce((acc, coef, index) => acc + coef * Math.pow(xtgt, index), 0);

    document.getElementById("n4").value = ypred.toFixed(2);

    var xValues = []; var yValues = [];
    var ycof = coefficients[0]; // initialize it to the first coefficient.

    // Generate the y values from the coeffs and xx arrays:
    for (var i = 0; i < xx.length; i++) {

      for (var j = 1; j < coefficients.length; j++) {

        ycof = (xx[i] ** (j)) * coefficients[j] + ycof;

      }

      yValues.push(parseFloat([ycof]));
      ycof = coefficients[0];
      xValues.push(xx[i]);
    }
    var m = mape(yy, yValues);
    document.getElementById("n3").value = m.toFixed(2);
  
  }
}
function mape(val1, val2) {
  var error = 0;
  for (var i = 0; i < val1.length; i++) {
    //omitting zeroes
    if (val1[i] != 0 && val2[i] != 0) {
      error += (Math.abs(val1[i] - val2[i]) / val1[i]) * 100;
    }
  }
  return error / val1.length
}