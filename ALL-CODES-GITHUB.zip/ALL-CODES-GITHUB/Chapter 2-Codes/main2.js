var powerCat = [];
var wspeed = [];
var wdirection = [];
var pressure = [];
var temperature = [];
var values = [];

function upload() {
    var fileUpload = document.getElementById("fileUpload");
    var reader = new FileReader();
    reader.readAsText(fileUpload.files[0]);
    reader.onload = function (e) {
        var csvData = e.target.result;
        var rows = csvData.split("\n");

    // Extract data from CSV rows and populate arrays
        for (var i = 1; i < rows.length; i++) {
            var columns = rows[i].split(",");
            wspeed.push(columns[1]);
            wdirection.push(columns[2]);
            pressure.push(columns[3]);
            temperature.push(columns[4]);
            powerCat.push(columns[5]);
        }
        for (var i = 1; i < rows.length; i++) {
            var columns = rows[i].split(",");
            var row = [];
            for (var j = 1; j < columns.length-1; j++) {
                row.push(parseFloat(columns[j]));
            }
            values.push(row);
        }
        // Get user input for k and feature values
        var k = parseFloat(document.getElementById("k").value);
        var inputs = [];
        inputs.push(parseFloat(document.getElementById("n1").value));
        inputs.push(parseFloat(document.getElementById("n2").value));
        inputs.push(parseFloat(document.getElementById("n3").value));
        inputs.push(parseFloat(document.getElementById("n4").value));
        var prediction = getKnnClassification(values, powerCat, k, inputs);
        document.getElementById("prediction").value = prediction;

        var predictions = [];
        for (var i = 0; i < 8760; i++) {
            var input = values[i];
        // Perform KNN classification for the provided input
            var pred = getKnnClassification(values, powerCat, k, input);
            predictions.push(pred);
        }
        // Prepare actual values for accuracy calculation
        var actuals = []
        for (var i = 0; i < 8760; i++) {
            actuals.push(powerCat[i]);
        }
        var accuracy = ACC(predictions, actuals);
        document.getElementById("accuracy").value = accuracy + "%";
    }
}

function getKnnClassification(x, y, k, inputs) {
    var distances = [];
    for (var i = 0; i < x.length; i++) {
        var distance = 0;
        for (var j = 0; j < inputs.length; j++) {
            distance = distance + (x[i][j] - inputs[j]) ** 2;
        }
        distance = distance ** 0.5;
        distances.push(distance);
    }
    var copy = distances.slice();
    copy.sort((a, b) => a - b);
    var nearestIdx = [];
    for (var i = 0; i < k; i++) {
        var idx = distances.indexOf(copy[i]);
        nearestIdx.push(idx);
        distances[idx] = Infinity;
    }
    var nearestNeighbours = [];
    for (var i = 0; i < k; i++) {
        nearestNeighbours.push(y[nearestIdx[i]]);
    }
    var classification = mode(nearestNeighbours);
    return classification;
}
// Function to calculate the mode of an array
function mode(arr) {
    var frequency = {};
    var maxFrequency = 0;
    var modes = [];
    for (var i = 0; i < arr.length; i++) {
        frequency[arr[i]] = (frequency[arr[i]] || 0) + 1;
        if (frequency[arr[i]] > maxFrequency) {
            maxFrequency = frequency[arr[i]];
        }
    }
    for (var key in frequency) {
        if (frequency[key] == maxFrequency) {
            modes.push(key);
        }
    }
    return modes[0];
}
// Function to calculate accuracy percentage
function ACC(arr1, arr2) {
    var n = arr1.length;
    var count = 0;
    for (var i = 0; i < n; i++) {
        if (arr1[i] == arr2[i]) {
            count++;
        }
    }
    return (count / n) * 100;
}