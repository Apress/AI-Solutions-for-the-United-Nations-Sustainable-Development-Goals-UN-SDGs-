var power = [];
var wspeed = [];
var wdirection = [];
var pressure = [];
var temperature = [];

var values = [];
function upload() {
    var fileUpload = document.getElementById("fileUpload");
    var reader = new FileReader();
    reader.readAsText(fileUpload.files[0]);
    reader.onload = function (e) {
        var csvData = e.target.result;
        var rows = csvData.split("\n");
    // Extract data from CSV rows and populate arrays
        for (var i = 1; i < 8760; i++) {
            var columns = rows[i].split(",");
            power.push(parseFloat(columns[0]));
            wspeed.push(columns[1]);
            wdirection.push(columns[2]);
            pressure.push(columns[3]);
            temperature.push(columns[4]);
        }

        for (var i = 1; i < 8760; i++) {
            var columns = rows[i].split(",");
            var row = [];
            for (var j = 1; j < columns.length; j++) {
                row.push(parseFloat(columns[j]));
            }
            values.push(row);
        }
        var Y = [];
        for (var i = 0; i < power.length; i++) {
            Y.push([power[i]]);
        }
        console.log(values.length);
        console.log(values[0].length);
        console.log(Y.length);
        console.log(Y[0].length);
    // Initialize MultivariateLinearRegression with values and Y
        var regression = new ML.MultivariateLinearRegression(values, Y);
        var inputs = [];
        inputs.push(parseFloat(document.getElementById("n1").value));
        inputs.push(parseFloat(document.getElementById("n2").value));
        inputs.push(parseFloat(document.getElementById("n3").value));
        inputs.push(parseFloat(document.getElementById("n4").value));
        var prediction = regression.predict(inputs);

        document.getElementById("prediction").value = prediction[0];

        var predictions = [];
        for (var i = 0; i < values.length; i++) {
            var input = values[i];
            var pred = regression.predict(input);
            predictions.push(pred);
        }

    // Prepare actual values for MAPE calculation
        var actuals = []
        for (var i = 0; i < values.length; i++) {
            actuals.push(power[i]);
        }
        var mape = MAPE(predictions, actuals);
        document.getElementById("mape").value = mape + "%";
    }
}

function mean(arr) {
    var sum = 0;
    for (var i = 0; i < arr.length; i++) {
        sum = sum + arr[i];
    }
    var mean = sum / arr.length;
    return mean;
}

function MAPE(arr1, arr2) {
    var n = arr1.length;
    var sumPercentageErrors = 0;
    for (let i = 0; i < n; i++) {
        var actual = arr1[i];
        var forecasted = arr2[i];
        if (actual === 0) {
            continue;
        }
        var percentageError = Math.abs((actual - forecasted) / actual) * 100;
        sumPercentageErrors += percentageError;
    }
    var meanPercentageError = sumPercentageErrors / n;
    return meanPercentageError;
}
// Function to calculate MLR coefficients
function getMLRCoeffs(x, y) {
    var X = [];
    for (var i = 0; i < x.length; i++) {
        var row = [];
        for (var j = -1; j < x[0].length; j++) {
            if (j == -1) {
                row.push(1);
            } else {
                row.push(x[i][j]);
            }
        }
        X.push(row);
    }
    var coeffs = math.multiply(math.inv(math.multiply(math.transpose(X), X)),
        math.transpose(X), y);
    return coeffs;
}
